import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  LogOut, 
  Wallet, 
  TrendingUp, 
  Settings, 
  Download, 
  Plus, 
  Clock, 
  Users, 
  Wifi,
  CreditCard,
  Router,
  Copy,
  RefreshCw,
  Zap,
  CheckCircle2,
  XCircle
} from 'lucide-react';
import { ClientFooter } from '../components/clientFooter';
import { format } from 'date-fns';
import jsPDF from 'jspdf';

export const ClientDashboard = () => {
  const [balance, setBalance] = useState(0);
  const [withdrawals, setWithdrawals] = useState([]);
  const [linkedRouters, setLinkedRouters] = useState([]);
  const [generatedTokens, setGeneratedTokens] = useState([]);
  const [currentVouchers, setCurrentVouchers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [voucherForm, setVoucherForm] = useState({
    quantity: 1,
    timeframe: '24Hrs'
  });
  const [isGenerating, setIsGenerating] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    // Simulate fetching data from API
    const fetchData = async () => {
      setIsLoading(true);
      
      // Simulate API calls
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Mock data
      setBalance(25000);
      setWithdrawals([
        { id: '1', amount: 10000, date: '2026-02-01', status: 'Completed' },
        { id: '2', amount: 5000, date: '2026-01-28', status: 'Completed' },
        { id: '3', amount: 15000, date: '2026-01-25', status: 'Pending' },
      ]);
      setLinkedRouters([
        { id: '1', name: 'Main-Lobby-R1', macAddress: 'AC:12:34:XX:YY:ZZ' },
        { id: '2', name: 'Pool-Area-AP', macAddress: '00:AA:BB:CC:DD:EE' },
        { id: '3', name: 'Guest-Wing-2', macAddress: '11:22:33:44:55:66' },
      ]);
      
      // Mock current vouchers data
      setCurrentVouchers([
        { 
          id: '1', 
          clientToken: '961173', 
          routerName: 'A8-29-48-9A-CE-07', 
          status: 'Active', 
          remainingTime: '2 hr(s)' 
        },
        { 
          id: '2', 
          clientToken: '915991', 
          routerName: 'A8-29-48-9A-CE-07', 
          status: 'Active', 
          remainingTime: '9 hr(s)' 
        }
      ]);
      
      setIsLoading(false);
    };

    fetchData();
  }, []);

  const handleLogout = () => {
    if (confirm('Are you sure you want to logout?')) {
      navigate('/client-login');
    }
  };

  const handleWithdraw = async () => {
    const amount = prompt('Enter withdrawal amount:');
    if (amount && parseInt(amount) > 0 && parseInt(amount) <= balance) {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setBalance(prev => prev - parseInt(amount));
      setWithdrawals(prev => [
        { id: Date.now().toString(), amount: parseInt(amount), date: new Date().toISOString().split('T')[0], status: 'Pending' },
        ...prev
      ]);
      
      alert('Withdrawal request submitted!');
    }
  };

  const generateTokenId = () => {
    return 'TWIST-' + Math.random().toString(36).substr(2, 8).toUpperCase();
  };

  const calculateExpiry = (timeframe) => {
    const now = new Date();
    let expiryTime = new Date(now);
    
    if (timeframe === '6Hrs') {
      expiryTime.setHours(now.getHours() + 6);
    } else if (timeframe === '12Hrs') {
      expiryTime.setHours(now.getHours() + 12);
    } else if (timeframe === '24Hrs') {
      expiryTime.setDate(now.getDate() + 1);
    } else if (timeframe === '1Week') {
      expiryTime.setDate(now.getDate() + 7);
    } else if (timeframe === '1Month') {
      expiryTime.setMonth(now.getMonth() + 1);
    }

    return expiryTime.toISOString();
  };

  const handleVoucherGenerate = async () => {
    if (voucherForm.quantity < 1 || voucherForm.quantity > 100) {
      alert('Please enter a quantity between 1 and 100');
      return;
    }

    setIsGenerating(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const newTokens = [];
    for (let i = 0; i < voucherForm.quantity; i++) {
      const newToken = {
        id: Date.now().toString() + i,
        tokenId: generateTokenId(),
        router: linkedRouters[Math.floor(Math.random() * linkedRouters.length)].name,
        duration: voucherForm.timeframe,
        expiryTime: calculateExpiry(voucherForm.timeframe),
        status: 'active',
        createdBy: 'Client'
      };
      newTokens.push(newToken);
    }
    
    setGeneratedTokens([...generatedTokens, ...newTokens]);
    setIsGenerating(false);

    alert(`Successfully generated ${voucherForm.quantity} voucher(s) for ${voucherForm.timeframe}`);
  };

  const handleDownloadVouchers = () => {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    
    doc.setFontSize(20);
    doc.text('Generated Voucher Details', pageWidth / 2, 20, { align: 'center' });
    
    const tokenData = generatedTokens.filter(token => token.createdBy === 'Client');
    
    let yPosition = 40;
    tokenData.forEach(token => {
      doc.setFontSize(12);
      doc.text(`Voucher Code: ${token.tokenId}`, 20, yPosition);
      doc.text(`Router: ${token.router}`, 20, yPosition + 10);
      doc.text(`Duration: ${token.duration}`, 20, yPosition + 20);
      doc.text(`Expires: ${format(new Date(token.expiryTime), 'MMM dd, hh:mm a')}`, 20, yPosition + 30);
      
      doc.setLineWidth(0.5);
      doc.setDrawColor(150);
      doc.line(20, yPosition + 35, pageWidth - 20, yPosition + 35);
      
      yPosition += 45;
      
      if (yPosition > 270) {
        doc.addPage();
        yPosition = 20;
      }
    });
    
    doc.save('generated-vouchers.pdf');
  };

  const handleDownloadToken = (tokenId) => {
    const token = generatedTokens.find(t => t.id === tokenId);
    if (token) {
      const doc = new jsPDF();
      doc.setFontSize(16);
      doc.text('Voucher Details', 20, 20);
      doc.setFontSize(12);
      doc.text(`Voucher Code: ${token.tokenId}`, 20, 40);
      doc.text(`Router: ${token.router}`, 20, 50);
      doc.text(`Duration: ${token.duration}`, 20, 60);
      doc.text(`Expires: ${format(new Date(token.expiryTime), 'MMM dd, hh:mm a')}`, 20, 70);
      doc.save(`voucher-${tokenId}.pdf`);
    }
  };

  const handleCopyVoucher = (voucherCode) => {
    navigator.clipboard.writeText(voucherCode);
    alert('Voucher code copied to clipboard');
  };

  const handleDeleteToken = (tokenId) => {
    setGeneratedTokens(generatedTokens.filter(token => token.id !== tokenId));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-800 text-lg font-medium">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-500 via-purple-600 to-blue-600">
      {/* Header */}
      <header className="bg-white/10 backdrop-blur-lg border-b border-white/20 p-4">
        <div className="container mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                <Wallet className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">Client Dashboard</h1>
                <p className="text-white/80 text-sm">Network Management</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 px-4 py-2 bg-red-500/20 text-white rounded-lg hover:bg-red-500/30 transition-all duration-200"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto p-4">
        {/* Dashboard Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 p-6 shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-r from-blue-500 to-green-500 flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-white/80 text-sm font-medium">Current Balance</h3>
                  <p className="text-2xl font-bold text-white">UGX {balance.toLocaleString()}</p>
                </div>
              </div>
            </div>
            <button
              onClick={handleWithdraw}
              className="w-full py-2 bg-gradient-to-r from-red-500 to-pink-500 text-white font-semibold rounded-lg hover:shadow-lg transition-all duration-200"
            >
              Withdraw Funds
            </button>
          </div>

          <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 p-6 shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center">
                  <Router className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-white/80 text-sm font-medium">Linked Routers</h3>
                  <p className="text-2xl font-bold text-white">{linkedRouters.length}</p>
                </div>
              </div>
            </div>
            <div className="text-white/60 text-sm">
              MAC Addresses linked to your account
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 p-6 shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-r from-yellow-500 to-orange-500 flex items-center justify-center">
                  <CreditCard className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-white/80 text-sm font-medium">Phone Number</h3>
                  <p className="text-2xl font-bold text-white">
                    0700 123 456
                  </p>
                </div>
              </div>
            </div>
            <div className="text-white/60 text-sm">
              Registered phone number
            </div>
          </div>
        </div>

        {/* Current Vouchers */}
        {currentVouchers.length > 0 && (
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 p-6 shadow-lg mb-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-full bg-gradient-to-r from-green-500 to-blue-500 flex items-center justify-center">
                <CreditCard className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-xl font-bold text-white">Current Vouchers in Use</h2>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/20">
                    <th className="text-left py-3 px-4 text-white/80 font-medium">Client Token</th>
                    <th className="text-left py-3 px-4 text-white/80 font-medium">Router Name</th>
                    <th className="text-left py-3 px-4 text-white/80 font-medium">Status</th>
                    <th className="text-left py-3 px-4 text-white/80 font-medium">Remaining Time</th>
                  </tr>
                </thead>
                <tbody>
                  {currentVouchers.map((voucher) => (
                    <tr key={voucher.id} className="border-b border-white/10 hover:bg-white/5">
                      <td className="py-3 px-4 font-mono text-white">{voucher.clientToken}</td>
                      <td className="py-3 px-4 text-white/80">{voucher.routerName}</td>
                      <td className="py-3 px-4">
                        <span className="flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium bg-green-500/20 text-green-400">
                          <CheckCircle2 className="w-3 h-3" />
                          {voucher.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-white/80">{voucher.remainingTime}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Voucher Generation */}
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 p-6 shadow-lg mb-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-full bg-gradient-to-r from-purple-500 to-blue-500 flex items-center justify-center">
              <Plus className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-xl font-bold text-white">Generate Vouchers</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-white/80 text-sm font-medium mb-2">Quantity</label>
              <input
                type="number"
                min="1"
                max="100"
                value={voucherForm.quantity}
                onChange={(e) => setVoucherForm(prev => ({ ...prev, quantity: parseInt(e.target.value) }))}
                className="w-full px-4 py-2 bg-white/20 border border-white/30 rounded-lg text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white/50"
                placeholder="Enter quantity"
              />
            </div>
            
            <div>
              <label className="block text-white/80 text-sm font-medium mb-2">Timeframe</label>
              <select
                value={voucherForm.timeframe}
                onChange={(e) => setVoucherForm(prev => ({ ...prev, timeframe: e.target.value }))}
                className="w-full px-4 py-2 bg-white/20 border border-white/30 rounded-lg text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white/50"
              >
                <option value="6Hrs">6 Hours</option>
                <option value="12Hrs">12 Hours</option>
                <option value="24Hrs">24 Hours</option>
                <option value="1Week">1 Week</option>
                <option value="1Month">1 Month</option>
              </select>
            </div>
          </div>

          <div className="flex gap-4 mt-6">
            <button
              onClick={handleVoucherGenerate}
              disabled={isGenerating}
              className="flex-1 py-3 bg-gradient-to-r from-green-500 to-blue-500 text-white font-semibold rounded-lg hover:shadow-lg transition-all duration-200 flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4" />
                  Generate Vouchers
                </>
              )}
            </button>
            
            <button
              onClick={handleDownloadVouchers}
              disabled={generatedTokens.length === 0}
              className="flex-1 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-semibold rounded-lg hover:shadow-lg transition-all duration-200 flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              Download PDF
            </button>
          </div>
        </div>

        {/* Currently Running Tokens */}
        {generatedTokens.length > 0 && (
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 p-6 shadow-lg mb-8">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-r from-green-500 to-blue-500 flex items-center justify-center">
                  <CreditCard className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-xl font-bold text-white">Currently Running Tokens</h2>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/20">
                    <th className="text-left py-3 px-4 text-white/80 font-medium">Voucher ID</th>
                    <th className="text-left py-3 px-4 text-white/80 font-medium">Router</th>
                    <th className="text-left py-3 px-4 text-white/80 font-medium">Duration</th>
                    <th className="text-left py-3 px-4 text-white/80 font-medium">Expiry</th>
                    <th className="text-left py-3 px-4 text-white/80 font-medium">Status</th>
                    <th className="text-left py-3 px-4 text-white/80 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {generatedTokens.filter(token => token.createdBy === 'Client').map((token) => (
                    <tr key={token.id} className="border-b border-white/10 hover:bg-white/5">
                      <td className="py-3 px-4 font-mono text-white">{token.tokenId}</td>
                      <td className="py-3 px-4 text-white/80">{token.router}</td>
                      <td className="py-3 px-4 text-white/80">{token.duration}</td>
                      <td className="py-3 px-4 text-white/80">{format(new Date(token.expiryTime), 'MMM dd, hh:mm a')}</td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-500/20 text-green-400">
                          Active
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex gap-2">
                          <button 
                            onClick={() => handleDownloadToken(token.id)}
                            className="text-green-400 hover:text-green-300 transition-colors"
                            title="Download PDF"
                          >
                            <Download className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => handleCopyVoucher(token.tokenId)}
                            className="text-blue-400 hover:text-blue-300 transition-colors"
                            title="Copy Voucher Code"
                          >
                            <Copy className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => handleDeleteToken(token.id)}
                            className="text-red-400 hover:text-red-300 transition-colors"
                            title="Delete"
                          >
                            <XCircle className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Linked Routers */}
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 p-6 shadow-lg mb-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-500 to-cyan-500 flex items-center justify-center">
              <Router className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-xl font-bold text-white">Linked Router MAC Addresses</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {linkedRouters.map((router) => (
              <div key={router.id} className="bg-white/10 rounded-xl p-4 border border-white/20">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-white font-semibold">{router.name}</h3>
                </div>
                <div className="text-white/60 text-sm">
                  MAC: {router.macAddress}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Withdrawal History */}
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 p-6 shadow-lg mb-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-full bg-gradient-to-r from-pink-500 to-red-500 flex items-center justify-center">
              <Clock className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-xl font-bold text-white">Withdrawal History</h2>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-white/20">
                  <th className="text-left py-3 px-4 text-white/80">Date</th>
                  <th className="text-left py-3 px-4 text-white/80">Amount</th>
                  <th className="text-left py-3 px-4 text-white/80">Status</th>
                </tr>
              </thead>
              <tbody>
                {withdrawals.map((withdrawal) => (
                  <tr key={withdrawal.id} className="border-b border-white/10 hover:bg-white/5">
                    <td className="py-3 px-4 text-white">{withdrawal.date}</td>
                    <td className="py-3 px-4 text-white">UGX {withdrawal.amount.toLocaleString()}</td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        withdrawal.status === 'Completed' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'
                      }`}>
                        {withdrawal.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>

      {/* Footer */}
      <ClientFooter />
    </div>
  );
};
